# Kiwanis Club of Stuart Website

A modern, professional website for the Kiwanis Club of Stuart, Florida.

## File Structure

```
kiwanis-website/
├── index.html          # Main HTML file
├── css/
│   └── styles.css      # All styles
├── js/
│   └── script.js       # JavaScript functionality
├── images/             # Place your images here
│   └── kiwanis-park.jpg (optional - placeholder will be used if not provided)
└── README.md           # This file
```

## Deployment Instructions

### Option 1: GitHub Pages (Recommended for Free Hosting)

1. Create a new GitHub repository (e.g., `kiwanis-website`)
2. Upload ALL files maintaining the folder structure:
   - index.html (root level)
   - css/styles.css
   - js/script.js
   - images/ folder (if you have images)
3. Go to repository Settings → Pages
4. Under "Source", select "main" branch
5. Click Save
6. Your site will be live at: `https://yourusername.github.io/kiwanis-website`

### Option 2: Netlify (Easiest)

1. Go to [netlify.com](https://netlify.com)
2. Sign up (free)
3. Click "Add new site" → "Deploy manually"
4. Drag the entire `kiwanis-website` folder
5. Your site will be live instantly with a custom URL

### Option 3: Your Existing Hosting

1. Access your web hosting (FTP, cPanel, or file manager)
2. Upload ALL files maintaining the folder structure
3. Make sure `index.html` is in the root directory
4. Ensure the `css/` and `js/` folders are uploaded with their files
5. Your site should be live immediately

### Option 4: Vercel

1. Go to [vercel.com](https://vercel.com)
2. Sign up (free)
3. Click "Add New" → "Project"
4. Import from GitHub or upload files
5. Deploy - your site will be live in seconds

## Important Notes

- **Keep folder structure intact** - the HTML file references css/styles.css and js/script.js
- All files must be uploaded together
- If you get a 404 error, check that:
  - index.html is in the root directory
  - css/ and js/ folders are present
  - File paths match (case-sensitive on some servers)

## Adding Your Own Images

To add your own image for the "About" section:
1. Place your image in the `images/` folder
2. Name it `kiwanis-park.jpg` (or update the filename in index.html line ~66)
3. Recommended image size: 800x600 pixels or larger

## Customization

- **Colors**: Edit `css/styles.css` - look for the `:root` section at the top
- **Content**: Edit `index.html` - content is clearly marked with comments
- **Contact Info**: Update the contact section in `index.html`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Questions?

If you encounter any issues during deployment, check:
1. Are all files uploaded?
2. Is the folder structure maintained?
3. Is index.html in the root directory?
4. Are css/ and js/ folders present?

For further assistance, refer to your hosting provider's documentation or GitHub Pages documentation.